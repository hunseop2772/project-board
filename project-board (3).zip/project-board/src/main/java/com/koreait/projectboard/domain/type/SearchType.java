package com.koreait.projectboard.domain.type;


// Enum class 상수를 사전에 정의할 때 사용
public enum SearchType {
    TITLE, CONTENT, ID, NICKNAME, HASHTAG

}
